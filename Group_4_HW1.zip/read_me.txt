the input of our model is (28,28,3), so you should run the following code to convert the grayscale image to RGB image, and then enter the network.

import cv2
rgb_test = []
for i in range(test_data.shape[0]):   
        im = test_data[i,:].reshape(28,28)
        im = Image.fromarray(np.uint8(im))
        im = im.convert('L')  
        rgb = im.convert('RGB')
        rgb = np.array(rgb)
        rgb_test.append(rgb)
print(rgb_test[1].shape)

Group member: WangXihao ZhangYiming LiPeihan ZhuChengxi